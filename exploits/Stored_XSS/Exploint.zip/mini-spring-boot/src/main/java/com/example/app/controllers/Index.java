package com.example.app.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.app.forms.FormLogin;

@Controller
public class Index {
    @GetMapping("/index")
    public String index(Model model) {
        return "index";
    }

    @GetMapping("/part1_1_vulnerable")
    public String part1_1_vuln(Model model) {
        model.addAttribute("formlogin", new FormLogin());

        return "part1_1_vulnerable";
    }
    
    @GetMapping("/part1_1_vulnerable_post")
    public String part1_1_vuln_post(HttpServletRequest request, @ModelAttribute FormLogin formLogin){
        System.out.println("Username: " + formLogin.getUsername());
        System.out.println("Password: " + formLogin.getPassword());

        return "redirect:" + request.getScheme() + "://localhost:8080/index"; 
    }

}